var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var survivaTime
var PLAY = 1;
var END = 0;
var gameState = PLAY;


var gameOverImg,restartImg
var jumpSound , checkPointSound, dieSound



function preload(){
  
  
monkey_running = loadAnimation("Monkey_0.png","Monkey_1.png","Monkey_2.png","Monkey_3.png","Monkey_4.png","Monkey_5.png","Monkey_6.png","Monkey_7.png","Monkey_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
  restartImg = loadImage("restart.png")
  gameOverImg = loadImage("gameOver.png")
  
  
 
 
}



function setup() {
  createCanvas(600, 200);
  
  monkey = createSprite(50,180,20,50);
monkey.addAnimation("running", monkey_running);
 monkey.scale = 0.5;
  
  ground = createSprite(400,350,900,10);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  
   
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
  
  //create Obstacle and Cloud Groups
  obstaclesGroup = createGroup();
  bananaGroup = createGroup();
  
  
  
  
  survivalTime = 0;
  
}

function draw() {
  
  background(180);
 text("Survival Time: "+ survivalTime, 500,50);
  
  
  
  if(gameState === PLAY){
     ground.velocityX = -4;
   score = score + Math.round(frameCount/60);
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
   
    if(keyDown("space")&& monkey.y >= 100) {
        monkey.velocityY = -12;
    }
    
    //add gravity
    monkey.velocityY = monkey.velocityY + 0.8
  
    //spawn the clouds
    spawnBananas();
  
    //spawn obstacles on the ground
    spawnObstacles();
    
    if(obstaclesGroup.isTouching(monkey)){
        gameState = END;
    }
  }
   else if (gameState === END) {
     gameOver.visible = true;
      restart.visible = true;
     
      ground.velocityX = 0;
      monkey.velocityY = 0
     
     
     
      //set lifetime of the game objects so that they are never destroyed
    obstaclesGroup.setLifetimeEach(-1);
    bananaGroup.setLifetimeEach(-1);
     
     obstaclesGroup.setVelocityXEach(0);
     bananaGroup.setVelocityXEach(0);
   }
  
 
  //stop trex from falling down
  monkey.collide(invisibleGround);
  
  
  
  drawSprites();
}

function spawnObstacles(){
 if (frameCount % 60 === 0){
   var obstacle = createSprite(400,165,10,40);
   obstacle.velocityX = -6;
   
    //generate random obstacles
    var rand = Math.round(random(1,6));
    switch(rand) {
      case 1: obstacle.addImage(obstacle1);
              break;
      case 2: obstacle.addImage(obstacle2);
              break;
      case 3: obstacle.addImage(obstacle3);
              break;
      case 4: obstacle.addImage(obstacle4);
              break;
      case 5: obstacle.addImage(obstacle5);
              break;
      case 6: obstacle.addImage(obstacle6);
              break;
      default: break;
    }
   
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.5;
    obstacle.lifetime = 300;
   
   //add each obstacle to the group
    obstaclesGroup.add(obstacle);
 }
}

function spawnBananas() {
  //write code here to spawn the clouds
  if (frameCount % 60 === 0) {
     banana = createSprite(600,100,40,10);
    banana.y = Math.round(random(10,60));
    banana.addImage(BananaImage);
    banana.scale = 0.5;
    banana.velocityX = -3;
    
     //assign lifetime to the variable
    banana.lifetime = 134;
    
    //adjust the depth
    banana.depth = banana.depth;
    monkey.depth = monkey.depth + 1;

   bananaGroup.add(banana);
    }
}






